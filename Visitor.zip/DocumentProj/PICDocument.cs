﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentProj
{
    public class PICDocument
    {
        private List<IDocumentPart> parts;

        public PICDocument()
        {
            parts = new List<IDocumentPart>();
        }

        public void Open()
        {
            foreach (var item in parts)
            {
                item.Paint();
            }
        }

        public void Close()
        {
            foreach (var item in parts.ToList())
            {
                item.Save();
            }
        }

        public void AddPart(IDocumentPart document)
        {
            parts.Add(document);
        }

        public void RemovePart(IDocumentPart document)
        {
            parts.Remove(document);
        }

        public void ConvertDocument(IConverter converter)
        {
            foreach (var part in parts)
            {
                part.Convert(converter);
            }
        }
    }
}
