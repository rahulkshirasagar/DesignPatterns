﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentProj
{
    class Program
    {
        static void Main(string[] args)
        {
            PICDocument pic = new PICDocument();
            pic.AddPart(new Header() { BannerContent = "Banner content" });
            pic.AddPart(new Paragraph() { Text = "Para text" });
            pic.AddPart(new Link() { Url = "Link url" });
            pic.Open();
            pic.Close();
            IConverter htmlConverter = new HtmlConverter();
            pic.ConvertDocument(htmlConverter);
        }
    }
}
