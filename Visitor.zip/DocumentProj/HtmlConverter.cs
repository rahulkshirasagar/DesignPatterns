﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentProj
{
    class HtmlConverter: IConverter
    {
        //public void Convert(List<IDocumentPart> documentParts)
        //{
        //    foreach (var part in documentParts)
        //    {
        //        if (part is Link)
        //        {
                    
        //        }

        //        if (part is Header)
        //        {
                    

        //        }

        //        if (part is Paragraph)
        //        {

        //        }
        //    }
        //}

        public void Convert(Header header)
        {
            Console.WriteLine($"<htmlheader>{header.BannerContent}<htmlheader>");
        }

        public void Convert(Paragraph paragraph)
        {
            Console.WriteLine($"<paragraph>{paragraph.Text}<paragraph>");

        }

        public void Convert(Link link)
        {
            Console.WriteLine($"<Link>{link.Url}<Link>");

        }
    }
}
