﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentProj
{
    public interface IConverter
    {
        void Convert(Header header);
        void Convert(Paragraph paragraph);
        void Convert(Link link);
        //void Convert(List<IDocumentPart> documents);
    }
}
