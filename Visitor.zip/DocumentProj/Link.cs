﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentProj
{
    public class Link : IDocumentPart
    {
        public string Url { get; set; }
        public void Paint()
        {
            Console.WriteLine("Link paint");
        }

        public void Save()
        {
            Console.WriteLine("Link save");
        }

        public void Convert(IConverter converter)
        {
            converter.Convert(this);
        }
    }
}
