﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    class Program
    {
        static void Main(string[] args)
        {
            A obj = new B();
            C c_obj = new D();
            IFoo foo = new Foo(obj);
            c_obj.Fun(foo);
        }
    }

    public interface IFoo
    {
        void Fooo(A a);
        void Fooo(B b);
        void Fooo(C c);
        void Fooo(D d);
    }

    public class Foo : IFoo
    {
        private IFun fun;
        public Foo(IFun f)
        {
            fun = f;
        }
        public void Fooo(A a)
        {
            Console.WriteLine("C-A implementation");
            a.Foo();
        }

        public void Fooo(B b)
        {
            Console.WriteLine("C-B implementation");
            b.Foo();
        }

        public void Fooo(C c)
        {
            Console.WriteLine("D-A implementation");
            fun.Foo();
        }

        public void Fooo(D d)
        {
            Console.WriteLine("D-B implementation");
            fun.Foo();
        }
    }

    public interface IFun
    {
        void Foo();
    }

    public class A: IFun
    {
        public virtual void Foo()
        {
            Console.WriteLine("A implementation");
        }
    }

    public class B : A
    {
        public override void Foo()
        {
            Console.WriteLine("B implementation");
        }
    }

    public class C
    {
        public virtual void Fun(IFoo obj)
        {
            obj.Fooo(this);
        }
    }

    public class D : C
    {
        public override void Fun(IFoo obj)
        {
            obj.Fooo(this);
        }
    }
}
